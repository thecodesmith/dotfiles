alias lz='lazybones'

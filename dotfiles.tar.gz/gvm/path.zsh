#THIS MUST BE AT THE END OF THE FILE FOR GVM TO WORK!!!
[[ -s "/Users/brian/.gvm/bin/gvm-init.sh" ]] && source "/Users/brian/.gvm/bin/gvm-init.sh"

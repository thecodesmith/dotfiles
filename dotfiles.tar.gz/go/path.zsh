export GOPATH=$PROJECTS/go
export PATH="$GOPATH/bin:$PATH"

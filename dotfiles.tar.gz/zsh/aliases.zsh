alias ll='ls -al'
alias reload!='. ~/.zshrc'

export PATH="$HOME/.rbenv/shims:$PATH"

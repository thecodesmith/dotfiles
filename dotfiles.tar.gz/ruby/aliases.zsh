alias rb='ruby'
alias sc='script/console'
alias sg='script/generate'
alias sd='script/destroy'

export CLASSPATH=".:/usr/local/lib/antlr-4.5-complete.jar:$CLASSPATH"

alias ev='vim ~/.vimrc'
alias ez='vim ~/.zshrc'

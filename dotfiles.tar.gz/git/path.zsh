export PATH=/usr/local/git/bin:${PATH}

alias python2=`which python`
alias python=`which python3`

alias venv='source ./venv/bin/activate'
alias dj='./manage.py'

alias ut='./manage.py test'
alias ft='./manage.py test functional_tests'
